/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
using System;
class EP6_5 {
  static void Main() {
    int a1,b1,d;
    
    Console.WriteLine("Valor de a: ");
    a1 = Int32.Parse(Console.ReadLine());
    Console.WriteLine("Valor de b: ");
    b1 = Int32.Parse(Console.ReadLine());
    Console.WriteLine("Valor de d: ");
    d = Int32.Parse(Console.ReadLine());
    
    while(a1<=0 || b1<=0 || d<=0)
    {
        if(a1<=0)
        {
            Console.WriteLine("el valor de a debe ser mayor a 0");
            Console.WriteLine("Valor de a: ");
            a1 = Int32.Parse(Console.ReadLine());
        }
        else if (b1<=0)
        {
            Console.WriteLine("el valor de b debe ser mayor a 0");
            Console.WriteLine("Valor de b: ");
            b1 = Int32.Parse(Console.ReadLine());
        }
        else if(d<=0)
        {
            Console.WriteLine("el valor de d debe ser mayor a 0");
            Console.WriteLine("Valor de d: ");
            d = Int32.Parse(Console.ReadLine()); 
        }
    }
    
    polinomio(a1,b1,d);
    
  }
  static void polinomio(int a, int b, int c)
    {
        if(a>1 && b>1 && c>0)
        {
        Console.WriteLine(a+"x^2 "+ "+ " + b + "x " + "+ " + c);
        }
        else if(a>0 && a<2 && b>1 && c>0)
        {
            Console.WriteLine("x^2 "+ "+ " + b + "x " + "+ " + c);
        }
        else if(a>1 && b>1 && b<2 && c>0)
        {
            Console.WriteLine("x^2 "+ "+ " + "x " + "+ " + c);
        }
    }
}