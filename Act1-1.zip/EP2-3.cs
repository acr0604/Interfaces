/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

using System;
class EP2_3 
{ 
    static void Main() 
    { 
        double area = 0, radio = 0;
        Console.WriteLine("Encontrar el Area de un Circulo.");
        Console.Write("Ingrese el radio del circulo: ");
        radio = Int32.Parse(Console.ReadLine());
        area =  2*Math.PI*Math.Pow(radio,2);
        Console.WriteLine("El Area del Circulo: " + area);
    }
}

