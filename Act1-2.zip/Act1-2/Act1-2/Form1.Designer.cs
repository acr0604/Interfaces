﻿namespace Botonesdeopcion
{
    partial class DlgConversionMetros
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ctDato = new System.Windows.Forms.TextBox();
            this.gbGrupoBotones1 = new System.Windows.Forms.GroupBox();
            this.btopYardas = new System.Windows.Forms.RadioButton();
            this.btopMillas = new System.Windows.Forms.RadioButton();
            this.btopPies = new System.Windows.Forms.RadioButton();
            this.btopPulgadas = new System.Windows.Forms.RadioButton();
            this.btConvertir = new System.Windows.Forms.Button();
            this.etDimension = new System.Windows.Forms.Label();
            this.btAcercade = new System.Windows.Forms.Button();
            this.etResultado = new System.Windows.Forms.Label();
            this.ctResultado = new System.Windows.Forms.TextBox();
            this.gbGrupoBotones1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ctDato
            // 
            this.ctDato.Location = new System.Drawing.Point(162, 32);
            this.ctDato.Name = "ctDato";
            this.ctDato.Size = new System.Drawing.Size(83, 20);
            this.ctDato.TabIndex = 0;
            this.ctDato.Text = "0";
            this.ctDato.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gbGrupoBotones1
            // 
            this.gbGrupoBotones1.Controls.Add(this.btopYardas);
            this.gbGrupoBotones1.Controls.Add(this.btopMillas);
            this.gbGrupoBotones1.Controls.Add(this.btopPies);
            this.gbGrupoBotones1.Controls.Add(this.btopPulgadas);
            this.gbGrupoBotones1.Location = new System.Drawing.Point(41, 58);
            this.gbGrupoBotones1.Name = "gbGrupoBotones1";
            this.gbGrupoBotones1.Size = new System.Drawing.Size(200, 114);
            this.gbGrupoBotones1.TabIndex = 1;
            this.gbGrupoBotones1.TabStop = false;
            this.gbGrupoBotones1.Text = "Unidad a Convertir";
            // 
            // btopYardas
            // 
            this.btopYardas.AutoSize = true;
            this.btopYardas.Location = new System.Drawing.Point(7, 89);
            this.btopYardas.Name = "btopYardas";
            this.btopYardas.Size = new System.Drawing.Size(58, 17);
            this.btopYardas.TabIndex = 3;
            this.btopYardas.Text = "&Yardas";
            this.btopYardas.UseVisualStyleBackColor = true;
            // 
            // btopMillas
            // 
            this.btopMillas.AutoSize = true;
            this.btopMillas.Location = new System.Drawing.Point(7, 66);
            this.btopMillas.Name = "btopMillas";
            this.btopMillas.Size = new System.Drawing.Size(51, 17);
            this.btopMillas.TabIndex = 2;
            this.btopMillas.Text = "&Millas";
            this.btopMillas.UseVisualStyleBackColor = true;
            // 
            // btopPies
            // 
            this.btopPies.AutoSize = true;
            this.btopPies.Location = new System.Drawing.Point(7, 42);
            this.btopPies.Name = "btopPies";
            this.btopPies.Size = new System.Drawing.Size(45, 17);
            this.btopPies.TabIndex = 1;
            this.btopPies.Text = "Pi&es";
            this.btopPies.UseVisualStyleBackColor = true;
            // 
            // btopPulgadas
            // 
            this.btopPulgadas.AutoSize = true;
            this.btopPulgadas.Checked = true;
            this.btopPulgadas.Location = new System.Drawing.Point(7, 19);
            this.btopPulgadas.Name = "btopPulgadas";
            this.btopPulgadas.Size = new System.Drawing.Size(69, 17);
            this.btopPulgadas.TabIndex = 0;
            this.btopPulgadas.TabStop = true;
            this.btopPulgadas.Text = "&Pulgadas";
            this.btopPulgadas.UseVisualStyleBackColor = true;
            // 
            // btConvertir
            // 
            this.btConvertir.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btConvertir.Location = new System.Drawing.Point(41, 191);
            this.btConvertir.Name = "btConvertir";
            this.btConvertir.Size = new System.Drawing.Size(87, 23);
            this.btConvertir.TabIndex = 2;
            this.btConvertir.Text = "&Convertir";
            this.btConvertir.UseVisualStyleBackColor = true;
            this.btConvertir.Click += new System.EventHandler(this.btConvertir_Click);
            // 
            // etDimension
            // 
            this.etDimension.AutoSize = true;
            this.etDimension.Location = new System.Drawing.Point(48, 35);
            this.etDimension.Name = "etDimension";
            this.etDimension.Size = new System.Drawing.Size(111, 13);
            this.etDimension.TabIndex = 3;
            this.etDimension.Text = "Dimension (en metros)";
            // 
            // btAcercade
            // 
            this.btAcercade.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btAcercade.Location = new System.Drawing.Point(158, 191);
            this.btAcercade.Name = "btAcercade";
            this.btAcercade.Size = new System.Drawing.Size(87, 23);
            this.btAcercade.TabIndex = 4;
            this.btAcercade.Text = "&Acerca de...";
            this.btAcercade.UseVisualStyleBackColor = true;
            this.btAcercade.Click += new System.EventHandler(this.btAcercade_Click);
            // 
            // etResultado
            // 
            this.etResultado.AutoSize = true;
            this.etResultado.Location = new System.Drawing.Point(48, 235);
            this.etResultado.Name = "etResultado";
            this.etResultado.Size = new System.Drawing.Size(58, 13);
            this.etResultado.TabIndex = 5;
            this.etResultado.Text = "Resultado:";
            // 
            // ctResultado
            // 
            this.ctResultado.BackColor = System.Drawing.Color.Black;
            this.ctResultado.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ctResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ctResultado.ForeColor = System.Drawing.Color.Lime;
            this.ctResultado.Location = new System.Drawing.Point(158, 226);
            this.ctResultado.Name = "ctResultado";
            this.ctResultado.Size = new System.Drawing.Size(87, 22);
            this.ctResultado.TabIndex = 6;
            this.ctResultado.Text = "0.000";
            this.ctResultado.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.ctResultado.WordWrap = false;
            // 
            // DlgConversionMetros
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(270, 285);
            this.Controls.Add(this.ctResultado);
            this.Controls.Add(this.etResultado);
            this.Controls.Add(this.btAcercade);
            this.Controls.Add(this.etDimension);
            this.Controls.Add(this.btConvertir);
            this.Controls.Add(this.gbGrupoBotones1);
            this.Controls.Add(this.ctDato);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "DlgConversionMetros";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Conversion de metros";
            this.gbGrupoBotones1.ResumeLayout(false);
            this.gbGrupoBotones1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox ctDato;
        private System.Windows.Forms.GroupBox gbGrupoBotones1;
        private System.Windows.Forms.RadioButton btopMillas;
        private System.Windows.Forms.RadioButton btopPies;
        private System.Windows.Forms.RadioButton btopPulgadas;
        private System.Windows.Forms.Button btConvertir;
        private System.Windows.Forms.RadioButton btopYardas;
        private System.Windows.Forms.Label etDimension;
        private System.Windows.Forms.Button btAcercade;
        private System.Windows.Forms.Label etResultado;
        private System.Windows.Forms.TextBox ctResultado;
    }
}

