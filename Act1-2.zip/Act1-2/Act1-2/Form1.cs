﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Botonesdeopcion
{
    public partial class DlgConversionMetros : Form
    {
        private double numeroActual;
        public DlgConversionMetros()
        {
            InitializeComponent();
        }

        private void btConvertir_Click(object sender, EventArgs e)
        {
            if (ctDato.Text.Length == 0) return;
            string texto = ctDato.Text;
            double Num = 0;
            if (btopPulgadas.Checked)
                Num = 39.3701;
            else if (btopPies.Checked)
                Num = 3.281;
            else if (btopMillas.Checked)
                Num = 0.00062;
            else if (btopYardas.Checked)
                Num = 1.0936;

            

            try
            {
                numeroActual = Convert.ToDouble(texto) * Num;
                ctResultado.Text = String.Format("{0:F3}", numeroActual);
                ctDato.Focus();
            }
            catch (FormatException ex)
            {
                MessageBox.Show(ex.Message);
                ctDato.Text = "0.000";
                ctResultado.Text = "0.000";
                ctDato.Focus();
            }
            catch (Exception ex)
            {
                if (texto == "-" || texto == "+" || texto == "*" || texto == "/")
                {
                    MessageBox.Show(ex.Message);
                    ctDato.Text = "0.000";
                    ctResultado.Text = "0.000";
                    ctDato.Focus();
                }
            }
           
        }

        private void btAcercade_Click(object sender, EventArgs e)
        {
            string msg = " Nombre: Alberto Chavez Rojas\n Matricula: A01231730";
            MessageBox.Show(msg);
        }
    }
}
